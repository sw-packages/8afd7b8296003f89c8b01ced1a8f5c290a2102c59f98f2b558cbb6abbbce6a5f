#ifndef _FONTCONFIG_SRC_FCSTDINT_H
#define _FONTCONFIG_SRC_FCSTDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "fontconfig 2.13.95"
/* generated using gnu compiler gcc (GCC) 12.0.1 20220125 (Red Hat 12.0.1-0) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
